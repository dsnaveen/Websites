#ifndef INVERSECDFDRIBUTION_H
#define INVERSECDFDRIBUTION_H

#include "DistributionBehavior.h"
#include "Points.h"

// Class for the method using Inverse CDF
class InverseCDFDistribution : public DistributionBehavior
{
public:
	InverseCDFDistribution(Points*);
	~InverseCDFDistribution();
	void distribute();

private:
	Points* m_Points;
};
#endif