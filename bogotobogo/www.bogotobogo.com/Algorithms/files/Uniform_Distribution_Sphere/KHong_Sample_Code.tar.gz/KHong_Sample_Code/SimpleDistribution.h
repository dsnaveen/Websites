#ifndef SIMPLEDISTRIBUTION_H
#define SIMPLEDISTRIBUTION_H

#include "DistributionBehavior.h"
#include "Points.h"

// This is a class for the simple method of distribution
class SimpleDistribution : public DistributionBehavior
{
public:
	SimpleDistribution(Points*);
	~SimpleDistribution();
	void distribute();

private:
	Points* m_Points;
};
#endif