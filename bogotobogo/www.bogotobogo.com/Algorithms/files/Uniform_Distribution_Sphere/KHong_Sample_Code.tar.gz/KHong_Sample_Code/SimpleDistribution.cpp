#include <cmath>
#include "SimpleDistribution.h"
#include "MyRandom.h"
#include "Defaults.h"
#include "Points.h"

// constructor
SimpleDistribution::SimpleDistribution(Points *ptr):m_Points(ptr)
{}

// destructor
SimpleDistribution::~SimpleDistribution()
{}

// simple distribution method which does not consider the Jacobian
// This is the equivalent of mapping points from a cylinder to a sphere
void SimpleDistribution::distribute()
{
	MyRandom m_Random;
	int nSample =  m_Points->getDensity();
	vector<double> x, y, z;
	double theta = 0, phi = 0;
	for(int i = 0; i < nSample; i++) {	
		theta = 2*PI*m_Random.irand(0,1);
		phi = PI*m_Random.irand(0,1);
		x.push_back(cos(theta)*sin(phi));
		y.push_back(sin(theta)*sin(phi));
		z.push_back(cos(phi));
	}
	m_Points->setXYZ(x,y,z);
}