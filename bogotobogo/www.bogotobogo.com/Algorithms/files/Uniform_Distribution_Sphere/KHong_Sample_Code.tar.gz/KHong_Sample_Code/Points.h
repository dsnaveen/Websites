#ifndef POINTS_H
#define POINTS_H
#include <vector>
#include "Sampling.h"
#include "MyRandom.h"

using namespace std;

// This class is holding place for the points generated
class Points
{
public:
	explicit Points(int);
	~Points();
	int getDensity() const;
	void setXYZ(vector<double>,vector<double>, vector<double>);
	int write() const;
	void display() const;

private:
	vector<double> m_x, m_y, m_z;
	int m_density;
	MyRandom m_Random;
};

#endif