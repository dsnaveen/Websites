#ifndef METHODCOLLECTION_H
#define METHODCOLLECTION_H

#include "DistributionBehavior.h"

// This class can make all the difference
// This is a collection of behavior - utilizing strategy pattern
class MethodCollection
{
public:
	MethodCollection();
	~MethodCollection();
	void setDistributionBehavior(DistributionBehavior*);
	void distribute();
	void setDisplay();
	void display();

private:
	DistributionBehavior* m_Distribution;
	//DisplayBehavior* m_Display;
};
#endif