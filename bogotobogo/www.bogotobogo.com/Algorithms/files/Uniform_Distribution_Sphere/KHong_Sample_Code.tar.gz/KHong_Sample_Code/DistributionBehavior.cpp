#include "DistributionBehavior.h"

// constructor
DistributionBehavior::DistributionBehavior()
{}

// distructor
DistributionBehavior::~DistributionBehavior()
{}
