#include "MethodCollection.h"
#include "DistributionBehavior.h"

// In current version, it has only the collection of distribution methods.
// However, this can be extend to include the methods of display as well as write.

// constructor
MethodCollection::MethodCollection()
 {}

// destructor
MethodCollection::~MethodCollection()
{}

// delegates the distribution to the object pointed by the passed parameter
void MethodCollection::setDistributionBehavior(DistributionBehavior* d)
{
	m_Distribution = d;
}

// decision on the method is done here
void MethodCollection::distribute()
{
	m_Distribution->distribute();
}

// Not implemented
void MethodCollection::setDisplay()
{}

// Not implemented
void  MethodCollection::display()
{}
