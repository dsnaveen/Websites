#include <iostream>
#include <cstdlib>
#include "Sampling.h"
#include "Points.h"
#include "Defaults.h"
#include "MethodCollection.h"
#include "InverseCDFDistribution.h"
#include "SimpleDistribution.h"

// Sampling class constructor
// Initialize a member for # of samples

Sampling::Sampling(const char* density)
{
	if(density) {
		m_density = atoi(density);
	}
	else {
		m_density = NO_OF_SAMPLES;
	}
	
	init();
}

// Print out # of the sample points
// instantiate MethodCollection
// instantiate Points

void Sampling::init()
{
	
	std::cout << "# of Sample points is = " << m_density << std::endl;

	// instantiate MethodCollection
	createMethodCollectionInstance();
	
	// instantiate Points
	createPointsInstance();
}

// Not implemented yet
void Sampling::display() const
{};

// write Cartesian coordinates (xyz)
int Sampling::write() const
{
	m_Points->write();
	return 0;
}

// destructor
Sampling::~Sampling()
{
	delete m_Points;
}

// create the object of Points 
void Sampling::createMethodCollectionInstance()
{
	m_MethodCollection = new MethodCollection();
}

// create the object of Points 
void Sampling::createPointsInstance()
{
	m_Points = new Points(m_density);
}
// generate smapling points for a given method
void Sampling::distribute()
{	
	m_MethodCollection->distribute();
}

// Here we can switch distribution method
void Sampling::setDistributionMethod()
{
	// switch the methods here
	// user can add a new class for other methods to use

	m_Distribution = new InverseCDFDistribution(this->m_Points);
	//m_Distribution = new SimpleDistribution(this->m_Points);

	// make an instance for the collection of methods
	m_MethodCollection = new MethodCollection();

	// Virtual method - passing down the distribution method to use
	m_MethodCollection->setDistributionBehavior(m_Distribution);
}
