#ifndef SAMPLING_H
#define SAMPLING_H

#include "MethodCollection.h"

class Points;

// This is kind of controller 
class Sampling
{
public:
	explicit Sampling(const char *);
	~Sampling();
	void distribute();
	void display() const;
	int write() const;
	void setDistributionMethod();

private:
	void init();
	void createMethodCollectionInstance();
	void createPointsInstance();
	int m_density;
	Points *m_Points;
	MethodCollection *m_MethodCollection;
	DistributionBehavior *m_Distribution;
};
#endif
