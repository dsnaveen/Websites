#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include "Points.h"
#include "Defaults.h"

using namespace std;

// constructor : initializing members
Points::Points(int density = NO_OF_SAMPLES):m_density(density), m_x(density),  m_y(density), m_z(density)
{}

// destructor
Points::~Points()
{}

// write Cartesian coordinates (xyz)
// this is the delegate from the Sampling.write()
int Points::write() const
{
	ofstream ofs;
	std::string fname = "sample.csv";
	try 
	{
		ofs.exceptions(std::ios_base::failbit | std::ios_base::badbit);
		ofs.open(fname.c_str());
	}
	catch(std::ios_base::failure &e)
	{
		cout << "Exception: " << e.what() <<  endl ;
		return -1 ;
	} 	

	for(int i = 0; i < m_density; i++) {
		ofs << m_x[i] << ',' << m_y[i]<< ',' << m_z[i]<< endl ;
	}
	ofs.close() ;
	cout << "Output file: " << fname << endl;
	return 0;
}

// Not implemented
void Points::display() const
{}

// get the density (# of sample points) from the Points object
int Points::getDensity() const
{
	return m_density;
}

// pass xyz for the distributed point to the Points class object
void Points::setXYZ(vector<double>x, vector<double>y, vector<double>z)
{
	m_x = x;
	m_y = y;
	m_z = z;
}
