#ifndef DEFAULTS_H
#define DEFAULTS_H

const int NO_OF_SAMPLES = 1000;
const double PI = 3.14159265;

#endif