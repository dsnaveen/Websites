#ifndef MYRANDOM_H
#define MYRANDOM_H

class MyRandom
{
public:
	MyRandom();
	// generate random number for the range (min, max)
	double irand(int min, int max);
private:

};

#endif