#ifndef DISTRIBUTIONBEHAVIOR_H
#define DISTRIBUTIONBEHAVIOR_H

// Abstract class for the distribution methods
class DistributionBehavior
{
public:
	DistributionBehavior();
	virtual ~DistributionBehavior();
	virtual void distribute() = 0;

private:

};
#endif