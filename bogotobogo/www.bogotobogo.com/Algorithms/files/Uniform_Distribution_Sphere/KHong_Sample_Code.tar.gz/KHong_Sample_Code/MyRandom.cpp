#include <ctime>
#include <cstdlib>
#include <iostream>
#include "MyRandom.h"

// Random class constructor
MyRandom::MyRandom()
{
	// initialize seed
	srand( (unsigned)time( NULL ) );
}

// generate random number for the range (min, max)
double MyRandom::irand(int min, int max) 
{
    return ((double)rand() / ((double)RAND_MAX + 1.0)) * (max - min) + min;
}
