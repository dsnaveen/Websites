/* Uniform distribution of points on the surface of a sphere */
   This code uses random approach, and using two methods:
   (1)Simple distribution 
      simple mapping uniformly distributed points on a cylinder to a sphere
   (2)Inverse CDF

   Program run:
   sampling [# of sample points]

   Online documentation - see Doxygen 
*/

#include "Sampling.h"

int main(int argc, char* argv[])
{
	// argv: # of sample poinst
	// if not given, default value defined in "Defaults.h" will be used
	Sampling mySample(argv[1]); 

	// set distribution method on run time
	// user can easily extend it by adding a new class
	mySample.setDistributionMethod();

	// generate the points
	mySample.distribute();

	// write data file
	mySample.write();

	// not implemented yet
	mySample.display();

	return 0;
}


