#include <cmath>
#include "InverseCDFDistribution.h"
#include "MyRandom.h"
#include "Defaults.h"
#include "Points.h"

// constructor
InverseCDFDistribution::InverseCDFDistribution(Points *ptr):m_Points(ptr)
{}

// destructor
InverseCDFDistribution::~InverseCDFDistribution()
{}

// correct way of distributing points
// Jacobin factor is taken into a consideration (solid angle dependency)
void InverseCDFDistribution::distribute()
{
	MyRandom m_Random;
	int nSample =  m_Points->getDensity();
	vector<double> x, y, z;
	double theta = 0, phi = 0;
	for(int i = 0; i < nSample; i++) {	
		theta = 2*PI*m_Random.irand(0,1);
		phi = acos(2*m_Random.irand(0,1)-1.0);
		x.push_back(cos(theta)*sin(phi));
		y.push_back(sin(theta)*sin(phi));
		z.push_back(cos(phi));
	}
	m_Points->setXYZ(x,y,z);
}