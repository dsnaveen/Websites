package com.bogotobogo.ImplicitIntent;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ImplicitIntentActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ViewContacts();  
    }
    
    private void ViewContacts() {
        try {
            Button viewContacts = (Button)findViewById(R.id.ViewContacts);
            
            viewContacts.setOnClickListener(new OnClickListener() {
            	
            	public void onClick(View v) {
            		Intent contacts = new Intent();
            		contacts.setAction(android.content.Intent.ACTION_VIEW);
            		contacts.setData(ContactsContract.Contacts.CONTENT_URI);
            		startActivity(contacts);
            	}
             });
        }
        catch (ActivityNotFoundException anfe) {
            	Log.e("ViewContacts","Viewing of Contacts failed", anfe);
        }    	
    } 
}
