#ifndef MYCONSTANTS_H
#define MYCONSTANTS_H
const int DataSize = 100000;
const int BufferSize = 8192;
#endif // MYCONSTANTS_H
