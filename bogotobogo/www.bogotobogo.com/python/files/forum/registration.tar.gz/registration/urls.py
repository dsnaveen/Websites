from django.conf.urls import patterns, include, url

urlpatterns = patterns('registration.views',
    url(r'^logout/$', 'logout'),
    url(r'^login/$', 'login'),
    url(r'^register/$', 'register_user'),
    url(r'^register_success/$', 'register_success'),
    url(r'^auth/$', 'auth_view'),
    url(r'^loggedin/$', 'loggedin'),
    url(r'^invalid/$', 'invalid_login'),

    # url(r'^register_user/$', 'register_user'),
)
