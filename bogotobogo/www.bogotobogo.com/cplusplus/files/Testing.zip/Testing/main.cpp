#include <iostream>
#include "foo.h"
using namespace std;

int main(void)
{
    cout << "main: This is test!" << endl;
    foo();
    return 0;
}


