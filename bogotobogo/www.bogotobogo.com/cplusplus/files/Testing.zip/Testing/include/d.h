// d.h
#pragma once
void HelloWorld();
