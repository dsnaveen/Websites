
#include <iostream>
#include "d.h "

using namespace std;


void foo()
{
  cout << "foo(): This is from foo!" << endl;
	HelloWorld();
}


